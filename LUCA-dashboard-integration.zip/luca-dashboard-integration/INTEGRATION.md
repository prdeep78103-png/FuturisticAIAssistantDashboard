# LUCA Dashboard Integration

## Included files

- `src/App.tsx` — complete LUCA React dashboard
- `src/index.css` — Tailwind import, design tokens, layout, animations, and responsive styling
- `public/luca-central-ai.mp4` — central AI voice-assistant animation

## Requirements

- React 19 or compatible React 18+
- TypeScript
- Tailwind CSS v4 through `@tailwindcss/vite`

No additional icon or UI package is required.

## Integration

1. Copy `src/App.tsx` into your project's `src` directory.
2. Copy `src/index.css` into your project's `src` directory.
3. Copy `public/luca-central-ai.mp4` into your project's `public` directory.
4. Ensure your React entry file imports the stylesheet:

```ts
import "./index.css";
```

5. Render the default `App` export from your entry file.
6. Ensure Tailwind CSS v4 and `@tailwindcss/vite` are configured in Vite.

The video is referenced as `/luca-central-ai.mp4`, so it must remain in the public directory or the source URL in `App.tsx` must be updated.
